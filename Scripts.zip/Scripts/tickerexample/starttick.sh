q tick.q marketdata hdb -p 5010 </dev/null >tickerplant.log 2>&1 &
q tick/r.q :5010 :5012 -p 5011 </dev/null >rdb.log 2>&1 &
q hdb/marketdata -p 5012 </dev/null >hdb.log 2>&1 &
q subscriber.q ::5010 ::5011 -p 5013 </dev/null >hdb.log 2>&1 &
