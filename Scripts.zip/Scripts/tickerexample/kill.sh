q kill.q ::5010 -p 15010 </dev/null >killtickerplant.log 2>&1 &
q kill.q ::5011 -p 15011 </dev/null >killrdb.log 2>&1 &
q kill.q ::5012 -p 15012 </dev/null >killhdb.log 2>&1 &
q kill.q ::5013 -p 15013 </dev/null >killhdb.log 2>&1 &
