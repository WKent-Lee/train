#include"k.h"		//Interfacting with kdb+
#include<stdio.h>
#include<string.h>	//for strcmp

/* Declare functions */
K makeq(K x);
K makenest(K x);
K maketab(K x);
K makedic(K x);
K makelist(K x);
K makeatom(K x);
void gen_random(char *s);

/* Decide which function to use */
K makeq(K x){
	
	//Check the input whether it is a character
	if( (x->t!=10) && (x->t!=-10) ){krr("character");return (K)0;};

	K result;

	switch((char)x->i){

		case 'b':case 'g':case 'x':case 'i':case 'j':case 'e':case 'f':case 'c':
		case 's':case 'p':case 'm':case 'd':case 'z':case 'n':case 'u':case 'v':
		case 't':{	result=makeatom(x);
				}break;

		case '0':case 'B':case 'X':case 'H':case 'I':case 'J':case 'E':case 'F':case 'C':
		case 'S':case 'P':case 'M':case 'D':case 'Z':case 'N':case 'U':case 'V':
		case 'T':{	result=makelist(x);
				}break;

		default:{	char buffer[100];
				int i;
			
				for(i=0;i<x->n;++i){buffer[i]=(char)kC(x)[i];}buffer[i]=0;	

				if( strcmp(buffer,"dictionary") == 0 ){result=makedic(x);}		
				
				else if( strcmp(buffer,"table") == 0 ){result=maketab(x);}

				else if( strcmp(buffer,"nest") == 0 ){result=makenest(x);}

				else{	printf("cannot make %s type\n",buffer);
					return (K)0;}

				}break;
	}
	
	return result;

}

/* Make a nested table for Q */
K makenest(K x){

	int i,j,ii;
	static const char ty[]="BXHIJEFCSPMDZNUVT0";

	//Construct the key of dictionary
	K key = ktn(KS,sizeof(ty)-1);

	for(i=0;i<sizeof(ty)-1;i++){
		char buf;
		sprintf(&buf,"%s%c","t_",ty[i]);
		char* buff=&buf;
		kS(key)[i]=ss(buff);
	}

	//Construct a nested list for each key	
	K val = ktn(0,sizeof(ty)-1);
	
	for(ii=0;ii<sizeof(ty)-1;ii++){

		K nest = ktn(0,3);
		for(j=0;j<3;j++){
			kK(nest)[j]=makelist(kc(ty[ii]));
		}

		kK(val)[ii]=nest;
	}

	//Build the nested table
	K result = xT(xD(key,val));

	return result;

}

/* Make a table for Q */
K maketab(K x){

	K result = xT(makedic(x));

	return result;
}

/* Make a dictionary for Q */
K makedic(K x){

	int i,j,ii;
	static const char head[]="bxhijefcspmdznuvt0";
	static const char ty[]="BXHIJEFCSPMDZNUVT0";

	//Construct the key of dictionary
	K key = ktn(KS,sizeof(head)-1);

	for(i=0;i<sizeof(head)-1;i++){
		char buf;
		sprintf(&buf,"%s%c","t_",head[i]);
		char* buff=&buf;
		kS(key)[i]=ss(buff);
	}

	//Construct a list for each key  
	K val = ktn(0,sizeof(ty)-1);

	for(ii=0;ii<sizeof(ty)-1;ii++){

		kK(val)[ii] = makelist(kc(ty[ii]));
	}
	
	//Build the dictionary
	K result = xD(key,val);
	
	return result;

}

/* Make a list for Q */
K makelist(K x){

	K result;

	int i,lenq=3;

	switch((char)x->i){

		//mixed
		case '0':{	char typec[]="bxhijefcspmdznuvt";
				result = ktn(0,lenq);
				for(i=0;i<lenq;i++){

					kK(result)[i] = makeatom(kc((int)typec[rand()%(sizeof(typec)-1)]));

				};
				}break;

		//boolean
		case 'B':{	result = ktn(KB,lenq);
				for(i=0;i<lenq;i++){
					
					kG(result)[i]=makeatom(kc((int)'b'))->g;

				};
				}break;

		//byte
		case 'X':{	result = ktn(KG,lenq);
				for(i=0;i<lenq;i++){

					kG(result)[i]=makeatom(kc((int)'x'))->g;
	
				};
				}break;

		//short
		case 'H':{	result = ktn(KH,lenq);
				for(i=0;i<lenq;i++){

					kH(result)[i]=makeatom(kc((int)'h'))->h;

				};
				}break;

		//int
		case 'I':{	result = ktn(KI,lenq);
				for(i=0;i<lenq;i++){

					kI(result)[i]=makeatom(kc((int)'i'))->i;

				};
				}break;

		//long
		case 'J':{	result = ktn(KJ,lenq);
				for(i=0;i<lenq;i++){
	
					kJ(result)[i]=makeatom(kc((int)'j'))->j;

				};
				}break;

		//real
		case 'E':{	result = ktn(KE,lenq);
				for(i=0;i<lenq;i++){

					kE(result)[i]=makeatom(kc((int)'e'))->e;

				};
				}break;

		//float
		case 'F':{	result = ktn(KF,lenq);
				for(i=0;i<lenq;i++){
	
					kF(result)[i]=makeatom(kc((int)'f'))->f;

				};
				}break;

		//char
		case 'C':{	result = ktn(KC,lenq);
				for(i=0;i<lenq;i++){

					kC(result)[i]=makeatom(kc((int)'c'))->i;

				};
				}break;

		//symbol
		case 'S':{	result = ktn(KS,lenq);
				for(i=0;i<lenq;i++){

					kS(result)[i]=makeatom(kc((int)'s'))->s;

				};
				}break;

		//timestamp
		case 'P':{	result = ktn(KP,lenq);
				for(i=0;i<lenq;i++){

					kJ(result)[i]=makeatom(kc((int)'p'))->j;

				};
				}break;

		//month
		case 'M':{	result = ktn(KM,lenq);
				for(i=0;i<lenq;i++){

					kI(result)[i]=makeatom(kc((int)'m'))->i;

				};
				}break;

		//date
		case 'D':{	result = ktn(KD,lenq);
				for(i=0;i<lenq;i++){

					kI(result)[i]=makeatom(kc((int)'d'))->i;

				};
				}break;

		//datetime
		case 'Z':{	result = ktn(KZ,lenq);
				for(i=0;i<lenq;i++){

					kF(result)[i]=makeatom(kc((int)'z'))->f;

				};
				}break;

		//timespan
		case 'N':{	result = ktn(KN,lenq);
				for(i=0;i<lenq;i++){

					kJ(result)[i]=makeatom(kc((int)'n'))->j;

				};
				}break;

		//minute
		case 'U':{	result = ktn(KU,lenq);
				for(i=0;i<lenq;i++){

					kI(result)[i]=makeatom(kc((int)'u'))->i;

				};
				}break;

		//second
		case 'V':{	result = ktn(KV,lenq);
				for(i=0;i<lenq;i++){

					kI(result)[i]=makeatom(kc((int)'v'))->i;

				};
				}break;

		//time
		case 'T':{	result = ktn(KT,lenq);
				for(i=0;i<lenq;i++){

					kI(result)[i]=makeatom(kc((int)'t'))->i;

				};
				}break;

		default:{	printf("cannot support %c type\n",x->i);
				return (K)0;
				}break;

	}

	return result;
}

/*  Make an atom for Q  */
K makeatom(K x){
	
	K result;

	switch((char)x->i){

		//boolean
		case 'b':{	result = kb(rand()%2);
				}break;

		//byte
		case 'x':{	result = kg(rand()%100);
				}break;

		//short
		case 'h':{	result = kh((short)rand()%100);
				}break;

		//int
		case 'i':{	result = ki((int)rand()%100);
				}break;

		//long
		case 'j':{	result = kj((long)(rand()%100));
				}break;

		//real
		case 'e':{	result = ke((float)(rand()%10000/100.0));
				}break;

		//float
		case 'f':{	result = kf((double)(rand()%10000/100.0));
				}break;

		//char		
		case 'c':{	static const char charq[]=
					"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
					"abcdefghijklmnopqrstuvwxyz";
				result = kc(charq[rand()%(sizeof(charq)-1)]);
				}break;

		//symbol
		case 's':{	char buffer;
				gen_random(&buffer);
				result = ks(ss(&buffer));
				}break;

		//timestamp
		case 'p':{	long long yearq = rand()%10+2010,
				monthq = rand()%12+1,
				dayq = rand()%28+1,
				hourq = rand()%24,
				minq = rand()%60,
				secq = rand()%60,
				nanoq = rand()%1000000000,
				tq = (((ymd(yearq,monthq,dayq)*24+hourq)*60+minq)*60+secq)*1000000000+nanoq;
				result = ktj(-KP,tq);
				}break;

		//month
		case 'm':{	int yearq = rand()%10+2010,
				monthq = rand()%12+1;
				result = ka(-KM);
				result->i = (yearq-2000)*12+monthq-1;
				}break;

		//date
		case 'd':{	int yearq = rand()%10+2010,
				monthq = rand()%12+1,
				dayq = rand()%28+1;
				result = kd(ymd(yearq,monthq,dayq));
				}break;

		//datetime
		case 'z':{	double yearq = rand()%10+2010,
				monthq = rand()%12+1,
				dayq = rand()%28+1,
				hourq = rand()%24,
				minq = rand()%60,
				secq = rand()%60,
				miliq  = rand()%1000,
				tq = ymd(yearq,monthq,dayq)+(hourq+(minq+(secq+miliq/1000)/60)/60)/24;
				result = kz(tq);
				}break;

		//timespan
		case 'n':{	long long dayq = rand()%10,
				hourq = rand()%24,
				minq = rand()%60,
				secq = rand()%60,
				nanoq = rand()%1000000000,
				tq = (((dayq*24+hourq)*60+minq)*60+secq)*1000000000+nanoq;
				result = ktj(-KN,tq);
				}break;

		//minute
		case 'u':{	int minq = rand()%60,
				secq = rand()%60,
				tq = minq*60+secq;
				result = ka(-KU);
				result->i = tq;
				}break;

		//second
		case 'v':{	int hourq = rand()%24,
				minq = rand()%60,
				secq = rand()%60,
				tq = (hourq*60+minq)*60+secq;
				result = ka(-KV);
				result->i = tq;
				}break;

		//time
		case 't':{	int hourq = rand()%24,
				minq = rand()%60,
				secq = rand()%60,
				miliq = rand()%1000,
				tq = ((hourq*60+minq)*60+secq)*1000+miliq;
				result = kt(tq);
				}break;
		
		default:{	printf("cannot support %c type\n",x->i);
				return (K)0;
				}break;

	}
	
	return result;

}

void gen_random(char *s){

	int i;

	static const char alpha[]=
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz";

	for(i=0;i<2;++i){

		s[i]=alpha[rand()%(sizeof(alpha)-1)];

	}

	s[i]=0;

}
